import React, { Component } from "react";
/* import { Link } from "react-router-dom";
import { toast } from "react-toastify"; */

class Home extends Component {
  state = {};

  render() {
    return <h1>Hello ready for new App ?</h1>;
  }
}

export default Home;
